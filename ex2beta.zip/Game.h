/*
 * Game.h
 *
 *  Created on: Nov 05, 2017
 *      Author: avi simson
 */
#ifndef REVERSI_GAME_H
#define REVERSI_GAME_H

#include "Board.h"
class Game {
    //class has a board, space left in board, matrix of x,y of
    // possible moves and 2 players.
    private:
        Board* board;
        char player1;
        char player2;
        int space;
        int** possiblePoints;
    public:
        Game(char p1, char p2);
        ~Game();
        void playGame();
        bool playOneTurn(char player);
        void scoreGame();
        void checkPossibleMoves(char player);
        bool checkUp(char player, int i, int j, bool flip);
        bool checkDown(char player, int i, int j, bool flip);
        bool checkLeft(char player, int i, int j, bool flip);
        bool checkRight(char player, int i, int j, bool flip);
        bool checkUpLeft(char player, int i, int j, bool flip);
        bool checkUpRight(char player, int i, int j, bool flip);
        bool checkDownLeft(char player, int i, int j, bool flip);
        bool checkDownRight(char player, int i, int j, bool flip);
};
#endif //REVERSI_GAME_H