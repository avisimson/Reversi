#include <iostream>
#include "Board.h"
#include "Game.h"
using namespace std;
//program creates reversi game board and prints it as output.
int main() {
    Game* game = new Game('X', 'O');
    game->playGame();
    delete game;
}