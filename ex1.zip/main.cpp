#include <iostream>
#include "Board.h"
using namespace std;
//program creates reversi game board and prints it as output.
int main() {
    Board* board = new Board();
    board->printBoard();
    delete board;
    return 0;
}