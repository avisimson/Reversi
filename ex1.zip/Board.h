/*
 * Board.h
 *
 *  Created on: Oct 29, 2017
 *      Author: avi simson
 */
#ifndef BOARD_H_
#define BOARD_H_
//matrix is the board status.
class Board {
private:
    char board[9][9];
// constructor function and print function.
public:
    Board();
    void printBoard();
};
#endif /* BOARD_H_ */