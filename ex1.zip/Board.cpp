/*
 * Board.cpp
 *
 *  Created on: Oct 29, 2017
 *      Author: avi simson
 */
#include <iostream>
#include "Board.h"
using namespace std;
// constructor. put initial board status on matrix.
Board::Board() {
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            board[i][j] = ' ';
        }
    }
    board[0][1] = '1';
    board[0][2] = '2';
    board[0][3] = '3';
    board[0][4] = '4';
    board[0][5] = '5';
    board[0][6] = '6';
    board[0][7] = '7';
    board[0][8] = '8';
    board[1][0] = '1';
    board[2][0] = '2';
    board[3][0] = '3';
    board[4][0] = '4';
    board[5][0] = '5';
    board[6][0] = '6';
    board[7][0] = '7';
    board[8][0] = '8';
    board[4][4] = 'O';
    board[5][5] = 'O';
    board[4][5] = 'X';
    board[5][4] = 'X';
}
// function prints board on output screen.
void Board::printBoard() {
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            cout << board[i][j];
            cout << " | ";
        }
        cout << "" <<endl;
        cout << "--------------------------------------" << endl;
    }
}